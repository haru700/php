<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */
 
/**
 * Defines the starting point of every application call.
 * Starts laying out how classes and methods are handled.
 */
class Front_Handler extends Eden_Class {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	/* Private Properties
	-------------------------------*/
	/* Get
	-------------------------------*/
	public static function i() {
		return self::_getSingleton(__CLASS__);
	}
	
	/* Magic
	-------------------------------*/
	public function __construct(Eden $app) {
		$app->listen('session', $this, 'setUser');	
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * When a session is started
	 * lets try to set the user data
	 * in registry
	 *
	 * @param Eden
	 * @param string
	 */
	public function setUser($event, $action) {
		$session 	= $this->Eden_Session()->getId();
		$user 		= $this->User()->model($session, 'session');
		
		$messages = array();
		if(isset($_SESSION['messages'])) {
			$messages = $_SESSION['messages'];
			unset($_SESSION['messages']);
		}
		
		$event->registry()
			->set('session', 'id', $session)
			->set('session', 'user', $user)
			->set('session', 'messages', $messages);
				
		return $this;
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
}