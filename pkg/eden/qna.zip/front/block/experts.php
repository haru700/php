<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Openovate Labs
 */

/**
 * Popular Tags block
 */
class Front_Block_Experts extends Eden_Block {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getMultiple(__CLASS__);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns the template variables in key value format
	 *
	 * @param array data
	 * @return array
	 */
	public function getVariables() {
		$users = front()
			->user()
			->search()
			->innerJoinOn('post', 'user_id=post_user')
			->innerJoinOn('vote', 'post_id=vote_post AND vote_value > 0')
			->setColumns('user.*', 'COUNT(post_user) AS total')
			->filterByPostType('answer')
			->setRange(25)
			->setGroup('post_user')
			->sortByTotal('DESC')
			->getCollection();
		
		return array('users' => $users);
	}
	
	/**
	 * Returns a template file
	 * 
	 * @param array data
	 * @return string
	 */
	public function getTemplate() {
		return realpath(dirname(__FILE__).'/experts.phtml');
	}
}