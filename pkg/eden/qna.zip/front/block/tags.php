<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Openovate Labs
 */

/**
 * Popular Tags block
 */
class Front_Block_Tags extends Eden_Block {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getMultiple(__CLASS__);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns the template variables in key value format
	 *
	 * @param array data
	 * @return array
	 */
	public function getVariables() {
		$tags = array();
		//get tag root
		$root = front()
			->category()
			->search()
			->filterByCategoryParent(0)
			->filterByCategoryTitle('tag')
			->setRange(1)
			->getModel();
		
		//if the root does exist
		if($root) {
			$tags = front()
				->category()
				->search()
				->setColumns('category.*, COUNT(category_id) AS total')
				->leftJoinOn('relation', "((relation_table1='category' AND ".
				"relation_id1=category_id AND relation_table2='post') OR ".
				"(relation_table2='category' AND relation_id2=category_id AND ".
				"relation_table1='post'))")
				->filterByCategoryParent($root['category_id'])
				->setRange(25)
				->setGroup('category_id')
				->sortByTotal('DESC')
				->getCollection();
		}
		
		return array('tags' => $tags);
	}
	
	/**
	 * Returns a template file
	 * 
	 * @param array data
	 * @return string
	 */
	public function getTemplate() {
		return realpath(dirname(__FILE__).'/tags.phtml');
	}
}