<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */

/**
 * Default logic to output a page
 */
class Front_Page_Ask extends Front_Page {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_errors = array();
	
	protected $_title = 'Ask a Question';
	protected $_class = 'support ask';
	protected $_template = '/ask.phtml';
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	public function render() {
		//authentication zone
		front()->authenticate();
		
		//if there was a submit and it's valid
		if(!empty($_POST) && $this->_validate()) {
			//process and redirect
			$this->_process();
		}
		
		$this->_body['errors'] 	= $this->_errors;
		$this->_body['tags'] 	= array();
		
		//if there are tags already
		if(isset($_POST['tags'])) {
			//add it to boy tags
			foreach($_POST['tags'] as $tag) {
				if(!trim($tag)) {
					continue;
				}
				
				$this->_body['tags'][] = $tag;
			}
			
		} 
		
		return $this->_page();
	}
	
	/* Protected Methods
	-------------------------------*/
	protected function _validate() {
		$this->_errors = array();
		
		if(!trim($_POST['title'])) {
			$this->_errors['title'] = 'Title cannot be empty.';
		}
		
		if(!trim($_POST['detail'])) {
			$this->_errors['detail'] = 'Detail cannot be empty.';
		}
		
		return empty($this->_errors);
	}
	
	protected function _process() {
		//get the user
		$userId = front()->registry()->get('session', 'user')->getUserId();
		
		//create the generic model
		$post = front()
			->post()->model()
			->setPostTitle($_POST['title'])
			->setPostDetail($_POST['detail'])
			->setPostUser($userId)
			->setPostType('question')
			->setPostCreated(time())
			->formatTime('post_created')
			->copy('post_created', 'post_updated');
		
		//get tag root
		$root = front()
			->category()
			->search()
			->filterByCategoryParent(0)
			->filterByCategoryTitle('tag')
			->setRange(1)
			->getModel();
		
		//if the root does not exist
		if(!$root) {
			//create it
			$root = front()
				->category()
				->model()
				->setCategoryTitle('tag')
				->setCategoryUpdated(time())
				->formatTime('category_updated')
				->save();
		}
		
		//loop through tags
		$tags = $_POST['tags'];
		foreach($tags as $i => $name) {
			//if there's no name
			if(!trim($name)) {
				//skip it
				unset($tags[$i]);
				continue;
			}
			
			//we are lower casing all tags
			$name = strtolower($name);
			
			//check to see if tag exists
			$tag = front()
				->category()
				->search()
				->filterByCategoryParent($root->getCategoryId())
				->filterByCategoryTitle($name)
				->setRange(1)
				->getModel();
			
			//if it doesn't
			if(!$tag) {
				//create it
				$tag = front()
					->category()
					->model()
					->setCategoryTitle($name)
					->setCategoryParent($root->getCategoryId())
					->setCategoryUpdated(time())
					->formatTime('category_updated')
					->save();	
			}
			
			//replace the tag name with the ID
			$tags[$i] = $tag->getCategoryId();
		}
		
		//bulk add tags
		$post->addCategory(array_values($tags))->save();
		
		//add a success message
		$_SESSION['messages'][] = array('success', 'Success creating question - '.$_POST['title'].'!');
		
		//redirect out
		front()->redirect('/question/'.$post->getPostSlug());
	}
	
	/* Private Methods
	-------------------------------*/
}
