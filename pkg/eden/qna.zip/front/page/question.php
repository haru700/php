<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */

/**
 * Default logic to output a page
 */
class Front_Page_Question extends Front_Page {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_errors = array();
	
	protected $_title = 'Question: %s';
	protected $_class = 'support question';
	protected $_template = '/question.phtml';
	
	protected $_meta = array(
		'title' 			=> 'Question: %s',
		'subject'	 		=> 'Question: %s',
		'copyright'			=> '2012-2013',
		'keywords' 			=> 'support, question',
		'classification' 	=> 'support, question',
		'revisit' 			=> '2 days',
		'revisit-after' 	=> '2 days');
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	public function render() {
		//get the slug from the URL
		$slug = front()->registry()->get('request', 'variables', 0);
		//get the post from the slug
		$post = front()->post()->model($slug, 'post_slug');
		
		//if there's no post
		if(!$post['post_id']) {
			//redirect out
			front()->redirect('/');
		}
		
		//set the page title
		$this->_title = $this->_meta['title'] = $this->_meta['subject'] = 
		sprintf($this->_title, $post['post_title']);
		
		//set the meta description
		$this->_meta['description'] = $this->_meta['abstract'] = front('type', $post['post_detail'])->summarize(20);
		
		//if there was a form submit and it's valid
		if(!empty($_POST) && $this->_validate()) {
			//process and redirect
			$this->_process($post);
		}
		
		$this->_body['summarize'] 	= false;
		
		//get the author
		$author = front()->user()->model($post->getPostUser());
		
		//add extra question details
		$post['user_id'] 		= $author->getUserId();
		$post['user_name'] 		= $author->getUserName();
		$post['user_facebook'] 	= $author->getAttributes('facebook_id');
		$post['user_picture'] 	= $author->getAttributes('picture');
		$post['votes'] 			= front()->vote()->getVotes($post->getPostId());
		$post['tags']			= $post->getCategories();
		
		//get the question comments
		$post['comments'] = front()->post()->search()
			->innerJoinOn('user', 'user_id=post_user')
			->filterByPostParent($post['post_id'])
			->filterByPostType('comment')
			->addFilter('(post_active = 1 OR post_active BETWEEN -4 AND -1)')
			->getCollection();
		
		//add extra comment details
		foreach($post['comments'] as $comment) {
			$author = front()->user()->model()->setUserId($comment['user_id']);
			$comment['user_facebook'] 	= $author->getAttributes('facebook_id');
			$comment['user_picture'] 	= $author->getAttributes('picture');
		}
		
		//get the answers
		$post['answers'] = front()->post()->search()
			->setColumns('post.*', 'user.*', 'COALESCE(SUM(vote_value), 0) as votes')
			->innerJoinOn('user', 'user_id=post_user')
			->leftJoinOn('vote', 'post_id=vote_post')
			->filterByPostParent($post['post_id'])
			->filterByPostType('answer')
			->addFilter('(post_active = 1 OR post_active BETWEEN -4 AND -1)')
			->setGroup('post_id')
			->sortByVotes('DESC')
			->getCollection();
		
		//we need to get the extra details and comments
		//for each of the answers
		foreach($post['answers'] as $answer) {
			//get the extra answer details
			$author = front()->user()->model()->setUserId($answer['user_id']);
			$answer['user_facebook'] 	= $author->getAttributes('facebook_id');
			$answer['user_picture'] 	= $author->getAttributes('picture');
			
			//get the answer comments
			$answer['comments'] = front()
				->post()->search()
				->innerJoinOn('user', 'user_id=post_user')
				->filterByPostParent($answer['post_id'])
				->filterByPostType('comment')
				->addFilter('(post_active = 1 OR post_active BETWEEN -4 AND -1)')
				->getCollection();
			
			//get the extra comment details
			foreach($answer['comments'] as $comment) {
				$author = front()->user()->model()->setUserId($comment['user_id']);
				$comment['user_facebook'] 	= $author->getAttributes('facebook_id');
				$comment['user_picture'] 	= $author->getAttributes('picture');
			}
		}
		
		
		$this->_body['post'] = $post;
		return $this->_page();
	}
	
	/* Protected Methods
	-------------------------------*/
	protected function _validate() {
		//save the post in the session in
		//case we need to authenticate first
		$_SESSION['post'] = $_POST;
		//authencation zone
		front()->authenticate(front()->registry()->get('request', 'string'));
		
		$this->_errors = array();
		
		if(!trim($_SESSION['post']['detail'])) {
			$this->_errors['detail'] = 'Detail cannot be empty.';
		}
		
		return empty($this->_errors);
	}
	
	protected function _process($post) {
		//get the user
		$userId = front()->registry()->get('session', 'user')->getUserId();
		
		//create the post and save
		$response = front()
			->post()->model()
			->setPostTitle(ucwords($_SESSION['post']['type']).' for '.$post->getPostTitle())
			->setPostDetail($_SESSION['post']['detail'])
			->setPostUser($userId)
			->setPostType($_SESSION['post']['type'])
			->setPostParent($_SESSION['post']['post'])
			->setPostCreated(time())
			->formatTime('post_created')
			->copy('post_created', 'post_updated')
			->save();
		
		//add a success message
		$_SESSION['messages'][] = array('success', 'Success adding '.$_SESSION['post']['type'].'!');
		
		//let's remove the post data from the session
		unset($_SESSION['post']);
		
		//redirect out
		$slug = front()->registry()->get('request', 'variables', 0);
		front()->redirect('/question/'.$slug);
	}
	
	/* Private Methods
	-------------------------------*/
}
