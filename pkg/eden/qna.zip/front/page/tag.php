<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */

/**
 * Default logic to output a page
 */
class Front_Page_Tag extends Front_Page {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_title = 'Support Tag: %s';
	protected $_class = 'support';
	protected $_template = '/tag.phtml';
	
	protected $_meta = array(
		'title' 			=> 'Support Tag: %s',
		'subject'	 		=> 'Support Tag: %s',
		'copyright'			=> '2012-2013',
		'keywords' 			=> 'support, community',
		'classification' 	=> 'support, community',
		'revisit' 			=> '2 days',
		'revisit-after' 	=> '2 days',
		'description' 		=> 'Support threads Results for %s.',
		'abstract' 			=> 'Support threads Results for %s.');
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	public function render() {
		//get the category slug from the URL
		$slug 	= front()->registry()->get('request', 'variables', 0);
		
		//get pagination stuff if it's there too
		$sort 	= front()->registry()->get('get', 'sort');
		$page 	= front()->registry()->get('get', 'page');
		
		$this->_body['summarize'] 	= true;
		
		//send out the category based on the slug
		$this->_body['category'] = front()->category()->model($slug, 'category_slug');
		
		//set the page title
		$this->_title = $this->_meta['title'] = $this->_meta['subject'] = 
		sprintf($this->_title, $this->_body['category']['category_title']);
		
		//set the meta description
		$this->_meta['description'] = $this->_meta['abstract'] = 
		sprintf($this->_title, $this->_body['category']['category_title']);
		
		//set up the default search
		$search = front()->category()
			->model($slug, 'category_slug')
			->searchPosts()
			->setColumns('post.*', 'user.*', 
				'COALESCE(SUM(vote_value), 0) as votes',
				'(SELECT COUNT(*) as answers FROM post as post2
				WHERE post2.post_type=\'answer\' AND post2.post_parent=post.post_id 
				AND (post2.post_active > 0 OR post2.post_active BETWEEN -1 AND -4)) 
				AS answers')
			->innerJoinOn('user', 'user_id=post.post_user')
			->leftJoinOn('vote', 'vote_post=post.post_id')
			->addFilter('post.post_type=%s', 'question')
			->addFilter('(post.post_active = 1 OR post_active BETWEEN -2 AND -1)')
			->setGroup('post.post_id')
			->sortByVotes('DESC')
			->setRange(50);
		
		//case for sorting
		switch($sort) {
			case 'new':
				$search->sortByPostCreated('DESC');
				break;
			case 'old':
				$search->sortByPostCreated('ASC');
				break;
			case 'unanswered':
				$search->sortByPostAnswers('ASC');
				break;
			default: 
				$search->sortByVotes('DESC');
				break;
		}
		
		//case for pagination
		if(is_numeric($page)) {
			$search->setPage($page);
		} else {
			$page = 1;
		}
		
		//now generate the final collection
		$this->_body['collection'] = $search->getCollection();
		
		//add extra collection details
		foreach($this->_body['collection'] as $post) {
			$author 				= front()->user()->model($post->getPostUser());
			$post['user_name'] 		= $author->getUserName();
			$post['user_facebook'] 	= $author->getAttributes('facebook_id');
			$post['user_picture'] 	= $author->getAttributes('picture');
			$post['tags']			= $post->getCategories();
		}
		
		//create a pagination block
		$this->_body['pagination'] = front()->template(__DIR__.'/_pagination.phtml', jquery()
			->block()
			->pagination($search->getTotal())
			->setRange(50)
			->setPage($page)
			->setUrl('/')
			->setQuery($_GET)
			->getVariables());
		
		return $this->_page();
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
}
