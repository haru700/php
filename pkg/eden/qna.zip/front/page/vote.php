<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */

/**
 * Default logic to output a page
 */
class Front_Page_Vote extends Front_Page {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_errors = array();
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	public function render() {
		//get the post id and the vote value from the URL
		$post 		= front()->registry()->get('request', 'variables', 0);
		$value 		= front()->registry()->get('request', 'variables', 1);
		
		//authentication zone
		front()->authenticate();
		
		//get the post from the post id given
		$row = front()->post()->getRow($post);
		
		//if there's no row found
		if(empty($row)) {
			//redirect out
			front()->redirect('/');
		}
		
		//get the user
		$user = front()->registry()->get('session', 'user')->getUserId();
		
		//if valud is less than 0
		if($value < 0) {
			//vote down
			front()->vote()->voteDown($post, $user);
		//otherwise
		} else {
			//vote up
			front()->vote()->voteUp($post, $user);
		}
		
		//add a success message
		$_SESSION['messages'][] = array('success', 'Thank you for voting!');
		
		//if this is a question
		if($row['post_parent'] == 0) {
			//redirect out
			front()->redirect('/question/'.$row['post_slug']);
		}
		
		//this is an answer
		$row = front()->post()->getRow($row['post_parent']);
		//redirect to the question
		front()->redirect('/question/'.$row['post_slug']);
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
}
