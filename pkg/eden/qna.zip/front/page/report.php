<?php //-->
/*
 * This file is part a custom application package.
 * (c) 2011-2012 Christian Blanquera <cblanquera@gmail.com>
 */

/**
 * Default logic to output a page
 */
class Front_Page_Report extends Front_Page {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_errors = array();
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	public function render() {
		//get the post id from the URL
		$post = front()->registry()->get('request', 'variables', 0);
		
		//authentication zone
		front()->authenticate();
		
		//get model from post id
		$row = front()->post()->model($post);
		
		//if there's no post found
		if(!$row->getPostId()) {
			//redirect out
			front()->redirect('/');
		}
		
		//if the user is the author or if the user is an admin (post_active==2)
		if($row->getPostUser() == front()->registry()->get('session', 'user')->getUserId()
		|| front()->registry()->get('session', 'user')->getUserActive() == 2) {
			//let's set post to inactive
			$_SESSION['messages'][] = array('success', 'We removed this '.$row->getPostType().'!');
			$row->setPostActive(0)->save();
		//if the post is active
		} else if($row->getPostActive() == 1) {
			//we first set it to -1
			$_SESSION['messages'][] = array('success', 'We received your report. Thank you!');
			$row->setPostActive(-1)->save();
		//the post has been flagged before
		} else {
			//substract 1 from post active
			$_SESSION['messages'][] = array('success', 'We received your report. Thank you!');
			$row->setPostActive($row->getPostActive()-1)->save();
		}
		
		//if this is a question
		if($row['post_parent'] == 0) {
			//go to the question
			front()->redirect('/question/'.$row['post_slug']);
		}
		
		//it could be an answer
		$row = front()->post()->getRow($row['post_parent']);
		
		//if this is now a parent
		if($row['post_parent'] == 0) {
			//go to the question
			front()->redirect('/question/'.$row['post_slug']);
		}
		
		//it could be a comment
		$row = front()->post()->getRow($row['post_parent']);
		//go to the question
		front()->redirect('/question/'.$row['post_slug']);
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
}
