<?php //-->
/*
 * This file is part a custom application package.
 */
 
require_once dirname(__FILE__).'/jquery.php';

/**
 * The starting point of every application call. If you are only
 * using the framework you can rename this function to whatever you
 * like.
 *
 */
function front() {
	$class = Front::i();
	if(func_num_args() == 0) {
		return $class;
	}
	
	$args = func_get_args();
	return $class->__invoke($args);
}

/**
 * Defines the starting point of every site call.
 * Starts laying out how classes and methods are handled.
 *
 * @package    Eden
 * @category   site
 */
class Front extends Eden {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_database 	= NULL;
	protected $_cache		= NULL;
	protected $_registry	= NULL;
	protected $_facebook	= array();
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getSingleton(__CLASS__);
	}
	
	public function __toString() {
		try {
			$response = (string) $this->registry()->get('response');
		} catch(Exception $e) {
			Eden_Error_Event::i()->exceptionHandler($e);
			$response = '';
		}
		
		return $response;
	}
	
	public function __construct() {
		parent::__construct();
		$this->_root = dirname(__FILE__);
		
		$this->setLoader();
		
		$this->_registry = Eden_Registry::i();
	}
	
	/* Bootstrap Methods
	-------------------------------*/
	/**
	 * Install
	 * 
	 * @return this
	 */
	public function install() {
		try {
			$this->post()->getRow(1);
		} catch(Exception $e) {
			$this->attribute()->install();
			$this->category()->install();
			$this->post()->install();
			$this->relation()->install();
			$this->user()->install();
			$this->vote()->install();
		}
		
		return $this;
	}
	
	/**
	 * Sets up the default database connection
	 *
	 * @return this
	 */
	public function setDatabase(array $info) {
		$this->_database = Eden_Mysql::i(
			$info['host'], $info['name'], 
			$info['user'], $info['pass']);
		
		return $this;
	}
	
	/**
	 * Lets the framework handle exceptions.
	 * This is useful in the case that you 
	 * use this framework on a server with
	 * no xdebug installed.
	 *
	 * @param string|null the error type to report
	 * @param bool|null true will turn debug on
	 * @return this
	 */
	public function setDebug($reporting = NULL, $default = NULL) {
		Eden_Error::i()->argument(1, 'int', 'null')->argument(2, 'bool', 'null');
		
		Eden_Loader::i()
			->load('Eden_Template')
			->Eden_Error_Event()
			->when(!is_null($reporting), 1)
			->setReporting($reporting)
			->when($default === true, 4)
			->setErrorHandler()
			->setExceptionHandler()
			->listen('error', $this, 'error')
			->listen('exception', $this, 'error')
			->when($default === false, 4)
			->releaseErrorHandler()
			->releaseExceptionHandler()
			->unlisten('error', $this, 'error')
			->unlisten('exception', $this, 'error');
		
		return $this;
	}
	
	/**
	 * Sets facebook config
	 *
	 * @param string
	 * @param string
	 * @return this
	 */
	public function setFacebookApp($key, $secret) {
		$this->_facebook = array('key' => $key, 'secret' => $secret);
		return $this;
	}
	
	/**
	 * Starts filters. Filters will handle when to run.
	 *
	 * @param string|array handlers
	 * @return Eden_Application
	 */
	public function setFilters(array $filters) {
		//for each handler as class
		foreach($filters as $class) {
			//try to
			try {
				//instantiate the class
				$this->$class($this);
			//when there's an error do nothing
			} catch(Exception $e){}
		}
		
		return $this;
	}
	
	/**
	 * Sets the application absolute paths
	 * for later referencing
	 * 
	 * @return this
	 */
	public function setPaths() {
		$this->registry()
			->set('path', 'root', 		$this->_root)
			->set('path', 'module', 	$this->_root.'/module')
			->set('path', 'config', 	$this->_root.'/config')
			->set('path', 'theme', 		$this->_root.'/theme')
			->set('path', 'page', 		$this->_root.'/front/page')
			->set('path', 'library', 	$this->_root.'/library')
			->set('path', 'web', 		$this->_root.'/web');
		
		return $this;
	}
	
	/**
	 * Sets request
	 *
	 * @return this
	 */
	public function setRequest() {
		$path = $_SERVER['REQUEST_URI'];
		if(strpos($path, '?') !== false) {
			list($path, $tmp) = explode('?', $path, 2);
		}
		
		$array 		= explode('/',  $path);
		$variables 	= array();
		$page 		= NULL;
		$buffer 	= $array;
		
		while(count($buffer) > 1) {
			$parts = ucwords(implode(' ', $buffer)); 
			$class = 'Front_Page'.str_replace(' ', '_', $parts);
			if(class_exists($class)) {
				$page = $class;
				break;
			}
			
			$variable = array_pop($buffer);
			array_unshift($variables, $variable);
		}
		
		$path = array(
			'string' 	=> $path, 
			'array' 	=> $array,
			'variables'	=> $variables);
		
		//set the request
		$this->registry()
			->set('server', $_SERVER)
			->set('cookie', $_COOKIE)
			->set('get', $_GET)
			->set('post', $_POST)
			->set('files', $_FILES)
			->set('request', $path)
			->set('page', $page);
		
		return $this;
	}
	
	/**
	 * Sets response
	 *
	 * @param EdenRegistry|null the request object
	 * @return this
	 */
	public function setResponse($default) {
		$page = $this->registry()->get('page');
		
		if(!$page || !class_exists($page)) {
			$page = $default;
		}
		
		//set the response data
		$response = $this->$page();
		
		$this->registry()->set('response', $response);
		
		return $this;
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns the attribute factory
	 *
	 * @return Attribute
	 */
	public function attribute() {
		return Attribute::i($this);
	}
	
	/**
	 * Returns the default database instance
	 *
	 * @return Eden_Database_Abstract
	 */
	public function database($key = NULL) {
		if(is_null($key)) {
			//return the default database
			return $this->_database;
		}
		
		return $this->registry()->get('database', $key);
	}
	
	/**
	 * Returns the category factory
	 *
	 * @return Category
	 */
	public function category() {
		return Category::i($this);
	}
	
	/**
	 * Returns jquery
	 *
	 * @return Jquery
	 */
	public function jquery() {
		return jquery();
	}
	
	/**
	 * Returns the post factory
	 *
	 * @return Post
	 */
	public function post() {
		return Post::i($this);
	}
	
	/**
	 * Returns the current Registry
	 *
	 * @return Eden_Registry
	 */
	public function registry() {
		return $this->_registry;
	}
	
	/**
	 * Returns the relation factory
	 *
	 * @return Relation
	 */
	public function relation() {
		return Relation::i($this);
	}
	
	/**
	 * Returns the user factory
	 *
	 * @return User
	 */
	public function user() {
		return User::i($this);
	}
	
	/**
	 * Returns the vote factory
	 *
	 * @return Vote
	 */
	public function vote() {
		return Vote::i($this);
	}
	
	/**
	 * Returns or saves the config 
	 * data given the key
	 *
	 * @param string
	 * @return array
	 */
	public function config($key, array $data = NULL) {
		$path = $this->path('config');
		$file = $this->Eden_File($path.'/'.$key.'.php');
		if(is_array($data)) {
			$file->setData($data);
			return $this;
		}
		
		if(!file_exists($file)) {
			return array();
		}
		
		return $file->getData();
	}
	
	/**
	 * Returns the absolute path 
	 * given the key
	 *
	 * @param string
	 * @return string
	 */
	public function path($key) {
		return $this->registry()->get('path', $key);
	}
	
	/**
	 * Outputs given a true or false statement
	 *
	 * @param string
	 * @return string
	 */
	public function output($yes, $valid, $no = NULL) {
		if($valid) {
			echo $yes;	
			return $this;
		}
		
		echo $no;
		return $this;
	}
	
	/**
	 * Redirects to a given URL
	 *
	 * @param string
	 * @return void
	 */
	public function redirect($location) {
		header('Location: '.$location);
		exit;
	}
	
	/**
	 * Returns the time passed relative to now
	 *
	 * @param string|int
	 * @param string
	 * @return string
	 */
	public function since($time, $format = 'F d, Y g:ia') {
		Front_Error::i()
			->argument(1, 'string', 'int')
			->argument(2, 'string');
		
		if(is_string($time)) {
			$time = strtotime($time);
		}
		
		$time = time() - $time; // to get the time since that moment
	
		$tokens = array (
			31536000 => 'year',
			2592000 => 'month',
			604800 => 'week',
			86400 => 'day',
			3600 => 'hour',
			60 => 'minute',
			1 => 'second'
		);
	
		foreach ($tokens as $unit => $text) {
			if ($time < $unit) continue;
			$numberOfUnits = floor($time / $unit);
			return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'').' ago';
		}
		
		return 'now';
	}
	
	/**
	 * Returns the template loaded with specified data
	 *
	 * @param array
	 * @return Eden_Template
	 */
	public function template($file, array $data = array()) {
		Front_Error::i()->argument(1, 'string');
		return Eden_Template::i()->set($data)->parsePhp($file);
	}
	
	/**
	 * Authenticates via facebook
	 *
	 * @return void
	 */
	public function authenticate() {
		$redirect 	= 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$user 		= $this->registry()->get('session', 'user');
		
		if(strpos($redirect, '?') !== false) {
			$redirect = substr($redirect, 0, strpos($redirect, '?'));
		}
		
		if(isset($_GET['code'])) {
			$access = front('facebook')
				->auth($this->_facebook['key'], $this->_facebook['secret'], $redirect)
				->getAccess($_GET['code']);
			
			//get user info form Facebook
			$facebook 	= front('facebook')->graph($access['access_token'])->getUser();
			$picture 	= Eden_Facebook_Graph::GRAPH_URL.$facebook['id'].'/picture';
			
			//insert or update new info
			$user = front()->user()
				->model($facebook['email'], 'user_email')
				->setUserName($facebook['name']);
			
			if(!$user->getUserId()) {
				$slug = $this->User()->getSlug($facebook['name']);
				
				$user
					->setUserEmail($facebook['email'])
					->setUserParent(0)
					->setUserSlug($slug)
					->setUserCreated(time())
					->formatTime('user_created')
					->copy('user_created', 'user_updated');
			}
			
			$user
				->setAttribute('picture', $picture)
				->setAttribute('facebook_id', $facebook['id'])
				->save();
			
			//relate user to session
			$this->database()
				->deleteRows('session', array(array('session_user=%s', $user->getUserId())))
				->insertRow('session', array(
					'session_id'	=> $this->Eden_Session()->getId(),
					'session_user'	=> $user->getUserId()));
			
			//they are now logged in
			$this->redirect($redirect);
			exit;
		} else if(!$user->getUserId()) {
			$this->redirect(front('facebook')
				->auth($this->_facebook['key'], $this->_facebook['secret'], $redirect)
				->setScope('email')
				->getLoginUrl());
				
			exit;
		}
	}
	
	/**
	 * Error trigger output
	 *
	 * @return void
	 */
	public function error($error, $event, $type, $level, 
		$class, $file, $line, $message, $trace, $offset) {
		$history = array();
		for(; isset($trace[$offset]); $offset++) {
			$row = $trace[$offset];
			 
			//lets formulate the method
			$method = $row['function'].'()';
			if(isset($row['class'])) {
				$method = $row['class'].'->'.$method;
			}
			 
			$rowLine = isset($row['line']) ? $row['line'] : 'N/A';
			$rowFile = isset($row['file']) ? $row['file'] : 'Virtual Call';
			 
			//add to history
			$history[] = array($method, $rowFile, $rowLine);
		}
		 
		echo Eden_Template::i()
			->set('history', $history)
			->set('type', $type)
			->set('level', $level)
			->set('class', $class)
			->set('file', $file)
			->set('line', $line)
			->set('message', $message)
			->parsePhp(dirname(__FILE__).'/front/error.phtml');
	}
	
	/* Protected Methods
	-------------------------------*/
	protected function _getVariables($path, $pattern) {
		$variables 			= array();
		
		//if the request path equals /
		if($path == '/') {
			//there would be no page variables
			return array();
		}
		
		//get the arrays
		$pathArray 		= explode('/', $path);
		$patternArray 	= explode('/', $pattern);
		
		//we do not need the first path because
		// /page/1 is [null,page,1] in an array
		array_shift($pathArray);
		array_shift($patternArray);
		
		//for each request path
		foreach($pathArray as $i => $value) {
			//if the page path is not set, is null or is '%'
			if(!isset($patternArray[$i]) 
				|| trim($patternArray[$i]) == NULL 
				|| $patternArray[$i] == '*') {
				//then we can assume it's a variable
				$variables[] = $pathArray[$i];
			}
		}
		
		return $variables;
	}
	
	/* Private Methods
	-------------------------------*/
}
