<?php //-->
/*
 * This file is part a custom application package.
 */
class Post extends Eden_Class {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_database 	= NULL;

	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getSingleton(__CLASS__);
	}
	
	public function __construct(Eden $app = NULL, $key = NULL) {
		if(is_null($app)) {
			$app = Eden::i()->getActiveApp();
		}
		
		$this->_database 	= $app->database($key);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns a post model
	 *
	 * @param mixed
	 * @param string
	 * @return Eden_Sql_Model
	 */
	public function model($value = NULL, $key = 'post_id') {
		$model = $this->Post_Model()->setDatabase($this->_database);
		
		if(!is_null($value)) {
			$model->load($value, $key);
		}
		
		return $model;
	}
	
	/**
	 * Returns a post row
	 *
	 * @param mixed
	 * @param string
	 * @return array
	 */
	public function getRow($value, $key = 'post_id') {
		return $this->_database->getRow('post', $key, $value);
	}
	
	/**
	 * Installs the post module
	 *
	 * @return this
	 */
	public function install() {
		//add to database
		$this->_database->query(self::$_schema);
		
		return $this;
	}
	
	/**
	 * Returns the search class
	 *
	 * @return Eden_Sql_Search
	 */
	public function search() {
		return $this->_database
			->search()
			->setTable('post')
			->setModel('Post_Model');
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
	/* Long Data
	-------------------------------*/
	private static $_schema = 
		'CREATE TABLE IF NOT EXISTS `post` (
		  `post_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		  `post_slug` varchar(255) NOT NULL,
		  `post_user` int(11) unsigned NOT NULL,
		  `post_parent` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `post_type` varchar(255) NOT NULL DEFAULT \'post\',
		  `post_title` varchar(255) DEFAULT NULL,
		  `post_detail` text,
		  `post_left` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `post_right` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `post_active` smallint(1) NOT NULL DEFAULT \'1\',
		  `post_created` datetime NOT NULL,
		  `post_updated` datetime NOT NULL,
		  PRIMARY KEY (`post_id`),
		  UNIQUE KEY `post_slug` (`post_slug`),
		  KEY `post_user` (`post_user`),
		  KEY `post_parent` (`post_parent`),
		  KEY `post_type` (`post_type`),
		  KEY `post_title` (`post_title`),
		  KEY `post_active` (`post_active`),
		  KEY `post_left` (`post_left`),
		  KEY `post_right` (`post_right`)
		) ENGINE=InnoDB  DEFAULT CHARSET=latin1;';
}