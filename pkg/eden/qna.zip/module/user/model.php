<?php //-->
/*
 * This file is part of the Eve package.
 * (c) 2011-2012 Openovate Labs
 *
 * Copyright and license information can be found at LICENSE.txt
 * distributed with this package.
 */

/**
 * User Model
 *
 * @package    Eve
 * @category   module
 * @author     Christian Blanquera cblanquera@openovate.com
 */
class User_Model extends Eden_Sql_Model {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_relations 	= array();
	protected $_attributes 	= array();
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getMultiple(__CLASS__);
	}
	
	public function __construct($data = array()) {
		if(!isset($data['user_parent'])) {
			$data['user_parent'] = 0;
		}
		
		if(!isset($data['user_active'])) {
			$data['user_active'] = 1;
		}
		
		$this->setTable('user');
		
		parent::__construct($data);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Relates category to user
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function addCategory($category) {
		User_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($category)) {
			$category = func_get_args();
		}
		
		foreach($category as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('category', 'category_slug', $relation);
				$relation = $row['category_id'];
			}
		
			$this->addRelation('category', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Relates post to user
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function addPost($post) {
		User_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($post)) {
			$post = func_get_args();
		}
		
		foreach($post as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('post', 'post_slug', $relation);
				$relation = $row['post_id'];
			}
		
			$this->addRelation('post', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Adds relation with post
	 *
	 * @param string|int
	 * @return this
	 */
	public function addRelation($table, $id) {
		User_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int');
			
		$this->_relations[] = array($table, $id, true);
		return $this;
	}
	
	/**
	 * Returns attributes related to user
	 *
	 * @param string|null
	 * @return array|string
	 */
	public function getAttributes($name = NULL) {
		User_Error::i()
			->argument(1, 'string', 'null');
			
		$search = $this->searchAttributes();
		
		if($name) {
			$search->filterByAttributeName($name);
			$row = $search->getRow();
			return $row['attribute_value'];
		}
		
		$rows = $search->getRows();
		$attributes = array();
		foreach($rows as $row) {
			$attributes[$row['attribute_name']] = $row['attribute_value'];
		}
		
		return $attributes;
	}
	
	/**
	 * Returns categories related to user
	 *
	 * @param string|null|bool
	 * @return array
	 */
	public function getCategories($type = false) {
		User_Error::i()->argument(1, 'string','null','bool');
		return $this->searchCategories($type)->getRows();
	}
	
	/**
	 * Returns the children of the user
	 *
	 * @param string|null user type
	 * @param bool recursive
	 * @param array sort
	 * @return array
	 */
	public function getChildren($recursive = false, array $sort = array()) {
		if(!isset($this->_data['user_id'])) {
			return array();
		}
		
		$join = $filter = array();
		
		if(!$recursive) {
			$filter[] = array('user_parent=%s', $this->_data['user_id']);
		} else {
			$row 	= $this->getRow($this->_data['user_id']);
			$left 	= $row['user_left'] + 1;
			$right 	= $row['user_right'] - 1;
			$filter[] = array('user_left BETWEEN %s AND %s', $left, $right);
			$sort['user_left'] = 'ASC';
		}
		
		return $this->_database->getRows('user', $join, $filter, $sort);
	}
	
	/**
	 * Returns all the parents for this user
	 *
	 * @param int user id
	 * @return array
	 */
	public function getParents() {
		if(!isset($this->_data['user_id'])) {
			return array();
		}
		
		$join = array();
		$row 	= $this->getRow($this->_data['user_id']);
		$filter = $row['user_left'].' BETWEEN user_left AND user_right';
		$sort['user_left'] = 'ASC';
		
		return $this->_database->getRows('user', $join, $filter, $sort);
	}
	
	/**
	 * Returns posts related to user
	 *
	 * @param string|null|bool
	 * @return array
	 */
	public function getPosts($type = false) {
		User_Error::i()->argument(1, 'string','null','bool');
		return $this->searchPosts($type)->getRows();
	}
	
	/**
	 * Returns the search class set to relations and post
	 *
	 * @param string
	 * @return Eden_Sql_Search
	 */
	public function getRelations($table, $type = false) {
		User_Error::i()->argument(1, 'string');
		return $this->searchRelation($table, $type)->getRows();
	}
	
	/**
	 * Returns the total amount of children
	 *
	 * @param int user id
	 * @param string|null user type
	 * @param bool recursive
	 * @return int
	 */
	public function getTotalChildren($recursive = false) {
		if(!isset($this->_data['user_id'])) {
			return 0;
		}
		
		$join = $filter = array();
		
		if(!$recursive) {
			$filter[] = array('user_parent=%s', $this->_data['user_id']);
		} else {
			$row 	= $this->getRow($this->_data['user_id']);
			$left 	= $row['user_left'] + 1;
			$right 	= $row['user_right'] - 1;
			$filter[] = array('user_left BETWEEN %s AND %s', $left, $right);
			$sort['user_left'] = 'ASC';
		}
		
		return $this->_database->getRows('user', $join, $filter);
	}
	
	/**
	 * Inserts model to database
	 *
	 * @param string
	 * @param Eden_Sql
	 * @return this
	 */
	public function insert($table = NULL, Eden_Sql_Database $database = NULL) {
		if($this->_data['user_slug'] && !$this->validSlug($this->_data['user_slug'])) {
			User_Error::i()
				->setMessage(User_Error::INVALID_SLUG)
				->addVariable($this->_data['user_slug'])
				->trigger();
		}
		
		$this->_data['user_created'] = date('Y-m-d H:i:s');
		$this->_data['user_updated'] = date('Y-m-d H:i:s');
		
		parent::insert($table, $database);
		
		$this->_setRelations()->_setAttributes()
			->_addLeftRight($this->_data['user_id'], 
			$this->_data['user_parent']);
		
		return $this;
	}
	
	/**
	 * Loads a user into the model
	 *
	 * @param mixed
	 * @param string
	 * @return this
	 */
	public function load($value, $key = 'user_id') {
		$row = $this->_database->getRow('user', $key, $value);
		parent::__construct($row);
		return $this;
	}
	
	/**
	 * Removes an extra attribute
	 *
	 * @param string
	 * @return this
	 */
	public function removeAttribute($name) {
		Post_Error::i()->argument(1, 'string');
		$this->_attributes[$name] = false;
		return $this;
	}
	
	/**
	 * Removes relation from category to user
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function removeCategory($category) {
		User_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($category)) {
			$category = func_get_args();
		}
		
		foreach($category as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('category', 'category_slug', $relation);
				$relation = $row['category_id'];
			}
		
			$this->removeRelation('category', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Removes relation from post to user
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function removePost($post) {
		User_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($post)) {
			$post = func_get_args();
		}
		
		foreach($post as $relation) {
		
			if(is_string($relation)) {
				$row = $this->_database->getRow('post', 'post_slug', $relation);
				$relation = $row['post_id'];
			}
		
			$this->removeRelation('post', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Removes relation with post
	 *
	 * @param string|int
	 * @return this
	 */
	public function removeRelation($table, $id) {
		User_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int');
			
		$this->_relations[] = array($table, $id, false);
		return $this;
	}
	
	/**
	 * Returns the search class set to atributes and user
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchAttributes($type = false) {
		$error = User_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['user_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('attribute', $type);
	}
	
	/**
	 * Returns the search class set to category and user
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchCategories($type = false) {
		$error = User_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['user_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('category', $type)->setModel('Category_Model');
	}
	
	/**
	 * Returns the search class set to post and user
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchPosts($type = false) {
		$error = User_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['user_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('post', $type)->setModel('Post_Model');
	}
	
	/**
	 * Returns the search class set to relations and post
	 *
	 * @param string
	 * @return Eden_Sql_Search
	 */
	public function searchRelation($table, $type = false) {
		$error = User_Error::i()
			->argument(1, 'string')
			->argument(2, 'string','null','bool');
		
		if(!isset($this->_data['user_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->Relation()->search('user', $this->_data['user_id'], $table, $type);
	}
	
	/**
	 * Adds an extra attribute
	 *
	 * @param string
	 * @param scalar|null
	 * @return this
	 */
	public function setAttribute($name, $value) {
		User_Error::i()
			->argument(1, 'string')
			->argument(2, 'scalar', 'null');
			
		$this->_attributes[$name] = $value;
		return $this;
	}
	
	/**
	 * Updates model to database
	 *
	 * @param string
	 * @param Eden_Sql_Database
	 * @param string|null|array
	 * @return this
	 */
	public function update($table = NULL, Eden_Sql_Database $database = NULL, $primary = NULL) {
		User_Error::i()
			->argument(1, 'string', 'null')
			->argument(3, 'string', 'null', 'array');
			
		$row = $this->_database->getRow('user', 'user_id', $this->_data['user_id']);
		
		if(!$this->validSlug($this->_data['user_slug'])) {
			User_Error::i()
				->setMessage(User_Error::INVALID_SLUG)
				->addVariable($this->_data['user_slug'])
				->trigger();
		}
		
		$this->_data['user_updated'] = date('Y-m-d H:i:s');
		
		if($this->_data['user_parent'] != $row['user_parent']) {
			$this->_updateLeftRight($userId, $this->_data['user_parent']);
		}
		
		parent::update($table, $database, $primary);
		
		$this->_setRelations()->_setAttributes();
		
		return $this;
	}
	
	/**
	 * Returns true if slug is not being used
	 *
	 * @param string
	 * @return bool
	 */
	public function validSlug($slug) {
		User_Error::i()->argument(1, 'string');
		$row = $this->_database->getRow('user', 'user_slug', $slug);
		
		//if there is no slug
		if(empty($row)) {
			//it's valid
			return true;
		}
		
		//if slug is set and slugs are equal and user ids are equal
		if(isset($this->_data['user_slug']) 
			&& $this->_data['user_slug'] == $row['user_slug'] 
			&& $this->_data['user_id'] == $row['user_id']) {
			return true;
		}
		
		return false;
	}
	
	/* Protected Methods
	-------------------------------*/
	protected function _addLeftRight($userId, $parent = 0) {
		//see: http://www.phpro.org/tutorials/Managing-Hierarchical-Data-with-PHP-and-MySQL.html#9
		//if there is no parent
		if($parent == 0) {
			//we need to get the greatest node
			$join = $filter = $sort = array();
			$sort['user_right'] = 'DESC';
			$row = $this->_database->getRows('user', $join, $filter, $sort, 0, 1, 0);
			
			$filter = $settings = array();
			$settings['user_left'] = $row['user_right']+1;
			$settings['user_right'] = $row['user_right']+2;
			$filter[] = array('user_id=%s', $userId);
			$this->_database->updateRows('user', $settings, $filter);
			return $this;
		}
			
		//let's get the parent
		$row = $this->_database->getRow('user', 'user_id', $parent);
		
		$settings = array('user_right' => 'user_right+2');
		$filter = 'user_right > '.$row['user_left'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		$settings = array('user_left' => 'user_left+2');
		$filter = 'user_left > '.$row['user_left'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		$filter = $settings = array();
		$settings['user_left'] = $row['user_left']+1;
		$settings['user_right'] = $row['user_left']+2;
		$filter[] = array('user_id=%s', $userId);
		$this->_database->updateRows('user', $settings, $filter);
		return $this;
	}
	
	protected function _removeLeftRight($userId) {
		$row = $this->_database->getRow('user', 'user_id', $userId);
		$width = $row['user_right'] - $row['user_left'] + 1;
		
		$settings = array('user_right' => 'user_right - '.$width);
		$filter = 'user_right > '.$row['user_right'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		$settings = array('user_left' => 'left_node - '.$width);
		$filter = 'user_left > '.$row['user_right'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		$settings = array('user_left' => 0, 'user_right' => 0);
		$filter = 'user_left BETWEEN '.$row['user_left'].' AND '.$row['user_right'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		return $this;
	}
	
	protected function _setAttributes() {
		//add categories first
		foreach($this->_attributes as $name => $value) {
			if($value === false) {
				$this->Attribute()->remove('user', $this->_data['user_id'], $name);
				continue;
			}
			
			$this->Attribute()->set('user', $this->_data['user_id'], $name, $value);
		}
		
		return $this;
	}
	
	protected function _setRelations() {
		//add categories first
		foreach($this->_relations as $relation) {
			if($relation[2]) {
				$this->Relation()->add('user', $this->_data['user_id'], $relation[0], $relation[1]);
				continue;
			}
			
			$this->Relation()->remove('user', $this->_data['user_id'], $relation[0], $relation[1]);
		}
		
		return $this;
	}
	
	protected function _updateLeftRight($userId, $parent) {
		//get the current row
		$row = $this->_database->getRow('user', 'user_id', $userId);
		$width = $row['user_right'] - $row['user_left'] + 1;
		
		//update the parent
		$settings = array('user_parent' => $parent);
		$filter = 'user_id ='.$row['user_id'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		//now get all the rows that need to change
		$join = $sort = array();
		$filter = 'user_left BETWEEN '.$row['user_left'].' AND '.$row['user_right'];
		$sort['user_left'] = 'ASC';
		$rows = $this->_database->getRows('user', $join, $filter);
		
		//update the right for the ones that is not the children
		$settings = array('user_right' => 'user_right - '.$width);
		$filter = 'user_right > '.$row['user_right'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		//update the left for the ones that is not the children
		$settings = array('user_left' => 'user_left - '.$width);
		$filter = 'user_left > '.$row['user_right'];
		$this->_database->updateRows('user', $settings, $filter, false);
		
		//now re add the nodes
		foreach($rows as $row) {
			$this->_addLeftRight($row['user_id'], $row['user_parent']);
		}
		
		return $this;
	}
	
	/* Private Methods
	-------------------------------*/
}