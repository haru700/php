<?php //-->
/*
 * This file is part of the Eve package.
 * (c) 2011-2012 Openovate Labs
 *
 * Copyright and license information can be found at LICENSE.txt
 * distributed with this package.
 */

/**
 * User Module
 *
 * @package    Eve
 * @category   module
 * @author     Christian Blanquera cblanquera@openovate.com
 */
class User extends Eden_Class {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_database 	= NULL;

	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getMultiple(__CLASS__);
	}
	
	public function __construct(Eden $app = NULL, $key = NULL) {
		if(is_null($app)) {
			$app = Eden::i()->getActiveApp();
		}
		
		$this->_database 	= $app->database($key);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns a post model
	 *
	 * @param mixed
	 * @param string
	 * @return Eden_Sql_Model
	 */
	public function model($value = NULL, $key = 'user_id') {
		$model = $this->User_Model()->setDatabase($this->_database);
		
		if(!is_null($value)) {
			
			if($key == 'session') {
				$session = $this->_database->getRow('session', 'session_id', $value);
				if(!$session) {
					return $model;
				}
				
				$value 	= $session['session_user'];
				$key 	= 'user_id';
			}
			
			$model->load($value, $key);
		}
		
		return $model;
	}
	
	/**
	 * Returns a post row
	 *
	 * @param mixed
	 * @param string
	 * @return array
	 */
	public function getRow($value, $key = 'user_id') {
		if($key == 'session') {
			$session = $this->_database->getRow('session', 'session_id', $value);
			if(!$session) {
				return NULL;
			}
			
			$value 	= $session['session_user'];
			$key 	= 'user_id';
		}
		
		return $this->_database->getRow('user', $key, $value);
	}
	
	/**
	 * Returns a generated slug, considering duplicates
	 *
	 * @param string
	 * @return string
	 */
	public function getSlug($name) {
		$slug = (string) eden('type', $name)->dasherize();
		$join = $filter = $sort = array();
		//SELECT * FROM `post` WHERE post_slug RLIKE '^test\-title\-[0-9]+$' ORDER BY post_slug DESC
		$filter[] = array('user_slug=%s OR user_slug RLIKE %s', $slug, 
					'^'.str_replace('-', '\\-', $slug).'-[0-9]+$');
					
		$sort = array('user_id' => 'DESC');
		$user = $this->_database->getRows('user', $join, $filter, $sort, 0, 1, 0);
		
		if(empty($user)) {
			return $slug;
		}
		
		$count = substr($user['user_slug'], strlen($slug)+1);
		$slug .= '-'.(is_numeric($count) ? $count+1 : 1);
		
		return $slug;
	}
	
	/**
	 * Installs the user module
	 *
	 * @return this
	 */
	public function install() {
		//add to database
		$this->_database->query(self::$_schema);
		
		return $this;
	}
	
	/**
	 * Returns the search class
	 *
	 * @return Eden_Sql_Search
	 */
	public function search() {
		return $this->_database
			->search()
			->setTable('user')
			->setModel('User_Model');
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
	/* Long Data
	-------------------------------*/
	private static $_schema = 
		'CREATE TABLE IF NOT EXISTS `user` (
		  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		  `user_slug` varchar(255) NOT NULL,
		  `user_email` varchar(255) NOT NULL,
		  `user_name` varchar(255) DEFAULT NULL,
		  `user_password` varchar(255) NOT NULL,
		  `user_parent` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `user_left` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `user_right` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `user_active` int(1) NOT NULL DEFAULT \'1\',
		  `user_created` datetime NOT NULL,
		  `user_updated` datetime NOT NULL,
		  PRIMARY KEY (`user_id`),
		  UNIQUE KEY `user_slug` (`user_slug`),
		  UNIQUE KEY `user_email` (`user_email`),
		  KEY `user_active` (`user_active`),
		  KEY `user_left` (`user_left`),
		  KEY `user_right` (`user_right`),
		  KEY `user_parent` (`user_parent`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;
		CREATE TABLE IF NOT EXISTS `session` (
		  `session_id` varchar(255) NOT NULL,
		  `session_user` int(11) unsigned NOT NULL,
		  UNIQUE KEY `session_id` (`session_id`),
		  KEY `session_user` (`session_user`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;';
}