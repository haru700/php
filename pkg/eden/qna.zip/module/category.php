<?php //-->
/*
 * This file is part of the Eve package.
 * (c) 2011-2012 Openovate Labs
 *
 * Copyright and license information can be found at LICENSE.txt
 * distributed with this package.
 */

/**
 * Category Module
 *
 * @package    Eve
 * @category   module
 * @author     Christian Blanquera cblanquera@openovate.com
 */
class Category extends Eden_Class {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_database 	= NULL;

	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getSingleton(__CLASS__);
	}
	
	public function __construct(Eden $app = NULL, $key = NULL) {
		if(is_null($app)) {
			$app = Eden::i()->getActiveApp();
		}
		
		$this->_database 	= $app->database($key);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Returns category block
	 *
	 * @return Category_Block
	 */
	public function block() {
		return $this->Category_Block($this->_database);
	}
	
	/**
	 * Returns a category model
	 *
	 * @param mixed
	 * @param string
	 * @return Eden_Sql_Model
	 */
	public function model($value = NULL, $key = 'category_id') {
		$model = $this->Category_Model()->setDatabase($this->_database);
		
		if(!is_null($value)) {
			$model->load($value, $key);
		}
		
		return $model;
	}
	
	/**
	 * Returns a category row
	 *
	 * @param mixed
	 * @param string
	 * @return array
	 */
	public function getRow($value, $key = 'category_id') {
		return $this->_database->getRow('category', $key, $value);
	}
	
	/**
	 * Installs the category module
	 *
	 * @return this
	 */
	public function install() {
		//add to database
		$this->_database->query(self::$_schema);
		return $this;
	}
	
	/**
	 * Returns the search class
	 *
	 * @return Eden_Sql_Search
	 */
	public function search() {
		return $this->_database
			->search()
			->setTable('category')
			->setModel('Category_Model');
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
	/* Long Data
	-------------------------------*/
	private static $_schema = 
		'CREATE TABLE IF NOT EXISTS `category` (
		  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		  `category_slug` varchar(255) NOT NULL,
		  `category_title` varchar(255) NOT NULL,
		  `category_parent` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `category_left` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `category_right` int(11) unsigned NOT NULL DEFAULT \'0\',
		  `category_active` int(1) NOT NULL DEFAULT \'1\',
		  `category_updated` datetime NOT NULL,
		  PRIMARY KEY (`category_id`),
		  UNIQUE KEY `category_slug` (`category_slug`),
		  KEY `category_parent` (`category_parent`),
		  KEY `category_right` (`category_right`),
		  KEY `category_left` (`category_left`),
		  KEY `category_active` (`category_active`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;';
}