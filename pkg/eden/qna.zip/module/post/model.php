<?php //-->
/*
 * This file is part of the Eve package.
 * (c) 2011-2012 Openovate Labs
 *
 * Copyright and license information can be found at LICENSE.txt
 * distributed with this package.
 */

/**
 * Post Model
 *
 * @package    Eve
 * @category   module
 * @author     Christian Blanquera cblanquera@openovate.com
 */
class Post_Model extends Eden_Sql_Model {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_relations 	= array();
	protected $_attributes 	= array();
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getMultiple(__CLASS__);
	}
	
	public function __construct($data = array()) {
		if(!isset($data['post_type'])) {
			$data['post_type'] = 'post';
		}
		
		if(!isset($data['post_active'])) {
			$data['post_active'] = 1;
		}
		
		if(!isset($data['post_parent'])) {
			$data['post_parent'] = 0;
		}
		
		$this->setTable('post');
		
		parent::__construct($data);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * Relates category to post
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function addCategory($category) {
		Post_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($category)) {
			$category = func_get_args();
		}
		
		foreach($category as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('category', 'category_slug', $relation);
				$relation = $row['category_id'];
			}
		
			$this->addRelation('category', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Adds relation with post
	 *
	 * @param string|int
	 * @return this
	 */
	public function addRelation($table, $id) {
		Post_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int');
			
		$this->_relations[] = array($table, $id, true);
		return $this;
	}
	
	/**
	 * Relates user to post
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function addUser($user) {
		Post_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($group)) {
			$file = func_get_args();
		}
		
		foreach($user as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('user', 'user_slug', $relation);
				$relation = $row['user_id'];
			}
		
			$this->addRelation('user', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Returns attributes related to user
	 *
	 * @param string|null
	 * @return array|string
	 */
	public function getAttributes($name = NULL) {
		Post_Error::i()
			->argument(1, 'string', 'null');
			
		$search = $this->searchAttributes();
		
		if($name) {
			$search->filterByAttributeName($name);
			$row = $search->getRow();
			return $row['attribute_value'];
		}
		
		$rows = $search->getRows();
		$attributes = array();
		foreach($rows as $row) {
			$attributes[$row['attribute_name']] = $row['attribute_value'];
		}
		
		return $attributes;
	}
	
	/**
	 * Returns categories related to post
	 *
	 * @param string|null|bool
	 * @return array
	 */
	public function getCategories($type = false) {
		Post_Error::i()->argument(1, 'string','null','bool');
		return $this->searchCategories($type)->getRows();
	}
	
	/**
	 * Returns the children of the post
	 *
	 * @param string|null post type
	 * @param bool recursive
	 * @param array sort
	 * @return array
	 */
	public function getChildren($type = NULL, $recursive = false, array $sort = array()) {
		Post_Error::i()
			->argument(1, 'string', 'null')
			->argument(2, 'bool');
		
		if(!isset($this->_data['post_id'])) {
			return array();
		}
		
		$join = $filter = array();
		
		if(!is_null($type)) {
			$filter[] = array('post_type=%s', $type);
		}
		
		if(!$recursive) {
			$filter[] = array('post_parent=%s', $this->_data['post_id']);
		} else {
			$row 	= $this->getRow($this->_data['post_id']);
			$left 	= $row['post_left'] + 1;
			$right 	= $row['post_right'] - 1;
			$filter[] = array('post_left BETWEEN %s AND %s', $left, $right);
			$sort['post_left'] = 'ASC';
		}
		
		return $this->_database->getRows('post', $join, $filter, $sort);
	}
	
	/**
	 * Returns all the parents for this post
	 *
	 * @param int post id
	 * @return array
	 */
	public function getParents() {
		if(!isset($this->_data['post_id'])) {
			return array();
		}
		
		$join = array();
		$row 	= $this->getRow($this->_data['post_id']);
		$filter = $row['post_left'].' BETWEEN post_left AND post_right';
		$sort['post_left'] = 'ASC';
		
		return $this->_database->getRows('post', $join, $filter, $sort);
	}
	
	/**
	 * Returns the search class set to relations and post
	 *
	 * @param string
	 * @return Eden_Sql_Search
	 */
	public function getRelations($table, $type = false) {
		Post_Error::i()
			->argument(1, 'string')
			->argument(2, 'string','null','bool');
			
		return $this->searchRelation($table, $type)->getRows();
	}
	
	/**
	 * Returns the total amount of children
	 *
	 * @param int post id
	 * @param string|null post type
	 * @param bool recursive
	 * @return int
	 */
	public function getTotalChildren($type = NULL, $recursive = false) {
		Post_Error::i()
			->argument(1, 'string', 'null')
			->argument(2, 'bool');
			
		if(!isset($this->_data['post_id'])) {
			return 0;
		}
		
		$join = $filter = array();
		
		if(!is_null($type)) {
			$filter[] = array('post_type=%s', $type);
		}
		
		if(!$recursive) {
			$filter[] = array('post_parent=%s', $this->_data['post_id']);
		} else {
			$row 	= $this->getRow($this->_data['post_id']);
			$left 	= $row['post_left'] + 1;
			$right 	= $row['post_right'] - 1;
			$filter[] = array('post_left BETWEEN %s AND %s', $left, $right);
			$sort['post_left'] = 'ASC';
		}
		
		return $this->_database->getRows('post', $join, $filter);
	}
	
	/**
	 * Returns users related to post
	 *
	 * @param string|null|bool
	 * @return array
	 */
	public function getUsers($type = false) {
		Post_Error::i()->argument(1, 'string','null','bool');
		return $this->searchUsers($type)->getRows();
	}
	
	/**
	 * Inserts model to database
	 *
	 * @param string
	 * @param Eden_Sql
	 * @return this
	 */
	public function insert($table = NULL, Eden_Sql_Database $database = NULL) {
		Post_Error::i()->argument(1, 'string', 'null');
		
		//if post user is set and it's a string
		if(isset($this->_data['post_user']) && !is_numeric($this->_data['post_user'])) {
			//get the user id and set it
			$this->_data['post_user'] = $this->_database->getRow('user', 'user_name', $this->_data['post_user']);
			$this->_data['post_user'] = $this->_data['post_user']['user_id'];
		}
		
		//if title is set
		if(isset($this->_data['post_title'])) {
			$this->_data['post_slug'] = $this->_getSlug($this->_data['post_title']);
		}
		
		$this->_data['post_created'] = date('Y-m-d H:i:s');
		$this->_data['post_updated'] = date('Y-m-d H:i:s');
		
		parent::insert($table, $database);

		$this->_setRelations()->_setAttributes()
			->_addLeftRight($this->_data['post_id'], 
			$this->_data['post_parent']);
		
		return $this;
	}
	
	/**
	 * Loads a post into the model
	 *
	 * @param mixed
	 * @param string
	 * @return this
	 */
	public function load($value, $key = 'post_id') {
		Post_Error::i()
			->argument(1, 'scalar')
			->argument(2, 'string');
			
		$row = $this->_database->getRow('post', $key, $value);
		parent::__construct($row);
		return $this;
	}
	
	/**
	 * Removes an extra attribute
	 *
	 * @param string
	 * @return this
	 */
	public function removeAttribute($name) {
		Post_Error::i()->argument(1, 'string');
		$this->_attributes[$name] = false;
		return $this;
	}
	
	/**
	 * Removes relation from category to post
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function removeCategory($category) {
		Post_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($category)) {
			$category = func_get_args();
		}
		
		foreach($category as $relation) {
			if(!is_numeric($relation)) {
				$row = $this->_database->getRow('category', 'category_slug', $relation);
				$relation = $row['category_id'];
			}
		
			$this->removeRelation('category', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Removes relation with post
	 *
	 * @param string|int
	 * @return this
	 */
	public function removeRelation($table, $id) {
		Post_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int');
			
		$this->_relations[] = array($table, $id, false);
		return $this;
	}
	
	/**
	 * Removes relation from user to post
	 *
	 * @param string|int|array
	 * @return this
	 */
	public function removeUser($user) {
		Post_Error::i()->argument(1, 'string', 'int', 'array');
		
		if(!is_array($group)) {
			$file = func_get_args();
		}
		
		foreach($user as $relation) {
		
			if(is_string($relation)) {
				$row = $this->_database->getRow('user', 'user_slug', $relation);
				$relation = $row['user_id'];
			}
		
			$this->removeRelation('user', $relation);
		}
		
		return $this;
	}
	
	/**
	 * Returns the search class set to atributes and user
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchAttributes($type = false) {
		$error = Post_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['post_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('attribute', $type);
	}
	
	/**
	 * Returns the search class set to category and post
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchCategories($type = false) {
		$error = Post_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['post_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('category', $type)->setModel('Category_Model');
	}
	
	/**
	 * Returns the search class set to relations and post
	 *
	 * @param string
	 * @return Eden_Sql_Search
	 */
	public function searchRelation($table, $type = false) {
		$error = Post_Error::i()
			->argument(1, 'string')
			->argument(2, 'string','null','bool');
		
		if(!isset($this->_data['post_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
			
		return $this->Relation()->search('post', $this->_data['post_id'], $table, $type);
	}
	
	/**
	 * Returns the search class set to user and post
	 *
	 * @param string|null|bool
	 * @return Eden_Sql_Search
	 */
	public function searchUsers($type = false) {
		$error = Post_Error::i()->argument(1, 'string','null','bool');
		
		if(!isset($this->_data['post_id'])) {
			$error->setMessage(Relation_Error::NO_PRIMARY_SEARCH)->trigger();
		}
		
		return $this->searchRelation('user', $type)->setModel('User_Model');
	}
	
	/**
	 * Adds an extra attribute
	 *
	 * @param string
	 * @param scalar|null
	 * @return this
	 */
	public function setAttribute($name, $value) {
		Post_Error::i()
			->argument(1, 'string')
			->argument(2, 'scalar', 'null');
			
		$this->_attributes[$name] = $value;
		return $this;
	}
	
	/**
	 * Updates model to database
	 *
	 * @param string
	 * @param Eden_Sql_Database
	 * @param string|null|array
	 * @return this
	 */
	public function update($table = NULL, Eden_Sql_Database $database = NULL, $primary = NULL) {
		Post_Error::i()
			->argument(1, 'string', 'null')
			->argument(3, 'string', 'null', 'array');
		
		//if post user is set and it's a string
		if(isset($this->_data['post_user']) && is_string($this->_data['post_user'])) {
			//get the user id and set it
			$this->_data['post_user'] = $this->_database->getRow('user', 'user_name', $this->_data['post_user']);
			$this->_data['post_user'] = $this->_data['post_user']['user_id'];
		}
		
		$row = $this->_database->getRow('post', 'post_id', $this->_data['post_id']);
		
		if($this->_data['post_title'] != $row['post_title']) {
			$this->_data['post_slug'] = $this->_getSlug($this->_data['post_title']);
		}
		
		$this->_data['post_updated'] = date('Y-m-d H:i:s');
		
		if($this->_data['post_parent'] != $row['post_parent']) {
			$this->_updateLeftRight($postId, $this->_data['post_parent']);
		}
		
		parent::update($table, $database, $primary);
		
		$this->_setRelations()->_setAttributes();
		
		return $this;
	}
	
	/* Protected Methods
	-------------------------------*/
	protected function _addLeftRight($postId, $parent = 0) {
		//see: http://www.phpro.org/tutorials/Managing-Hierarchical-Data-with-PHP-and-MySQL.html#9
		//if there is no parent
		if($parent == 0) {
			//we need to get the greatest node
			$join = $filter = $sort = array();
			$sort['post_right'] = 'DESC';
			$row = $this->_database->getRows('post', $join, $filter, $sort, 0, 1, 0);
			
			$filter = $settings = array();
			$settings['post_left'] = $row['post_right']+1;
			$settings['post_right'] = $row['post_right']+2;
			$filter[] = array('post_id=%s', $postId);
			$this->_database->updateRows('post', $settings, $filter);
			return $this;
		}
			
		//let's get the parent
		$row = $this->_database->getRow('post', 'post_id', $parent);
		
		$settings = array('post_right' => 'post_right+2');
		$filter = 'post_right > '.$row['post_left'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		$settings = array('post_left' => 'post_left+2');
		$filter = 'post_left > '.$row['post_left'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		$filter = $settings = array();
		$settings['post_left'] = $row['post_left']+1;
		$settings['post_right'] = $row['post_left']+2;
		$filter[] = array('post_id=%s', $postId);
		$this->_database->updateRows('post', $settings, $filter);
		return $this;
	}
	
	protected function _getSlug($title) {
		$slug = (string) eden('type', $title)->dasherize();
		$join = $filter = $sort = array();
		//SELECT * FROM `post` WHERE post_slug RLIKE '^test\-title\-[0-9]+$' ORDER BY post_slug DESC
		$filter[] = array('post_slug=%s OR post_slug RLIKE %s', $slug, 
					'^'.str_replace('-', '\\-', $slug).'-[0-9]+$');
					
		$sort = array('post_id' => 'DESC');
		$post = $this->_database->getRows('post', $join, $filter, $sort, 0, 1, 0);
		
		if(empty($post)) {
			return $slug;
		}
		
		$count = substr($post['post_slug'], strlen($slug)+1);
		$slug .= '-'.(is_numeric($count) ? $count+1 : 1);
		
		return $slug;
	}
	
	protected function _removeLeftRight($postId) {
		$row = $this->_database->getRow('post', 'post_id', $postId);
		$width = $row['post_right'] - $row['post_left'] + 1;
		
		$settings = array('post_right' => 'post_right - '.$width);
		$filter = 'post_right > '.$row['post_right'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		$settings = array('post_left' => 'left_node - '.$width);
		$filter = 'post_left > '.$row['post_right'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		$settings = array('post_left' => 0, 'post_right' => 0);
		$filter = 'post_left BETWEEN '.$row['post_left'].' AND '.$row['post_right'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		return $this;
	}
	
	protected function _setAttributes() {
		//add categories first
		foreach($this->_attributes as $name => $value) {
			if($value === false) {
				$this->Attribute()->remove('post', $this->_data['post_id'], $name);
				continue;
			}
			
			$this->Attribute()->set('post', $this->_data['post_id'], $name, $value);
		}
		
		return $this;
	}
	
	protected function _setRelations() {
		//add categories first
		foreach($this->_relations as $relation) {
			if($relation[2]) {
				$this->Relation()->add('post', $this->_data['post_id'], $relation[0], $relation[1]);
				continue;
			}
			
			$this->Relation()->remove('post', $this->_data['post_id'], $relation[0], $relation[1]);
		}
		
		return $this;
	}
	
	protected function _updateLeftRight($postId, $parent) {
		//get the current row
		$row = $this->_database->getRow('post', 'post_id', $postId);
		$width = $row['post_right'] - $row['post_left'] + 1;
		
		//update the parent
		$settings = array('post_parent' => $parent);
		$filter = 'post_id ='.$row['post_id'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		//now get all the rows that need to change
		$join = $sort = array();
		$filter = 'post_left BETWEEN '.$row['post_left'].' AND '.$row['post_right'];
		$sort['post_left'] = 'ASC';
		$rows = $this->_database->getRows('post', $join, $filter);
		
		//update the right for the ones that is not the children
		$settings = array('post_right' => 'post_right - '.$width);
		$filter = 'post_right > '.$row['post_right'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		//update the left for the ones that is not the children
		$settings = array('post_left' => 'post_left - '.$width);
		$filter = 'post_left > '.$row['post_right'];
		$this->_database->updateRows('post', $settings, $filter, false);
		
		//now re add the nodes
		foreach($rows as $row) {
			$this->_addLeftRight($row['post_id'], $row['post_parent']);
		}
		
		return $this;
	}
	
	/* Private Methods
	-------------------------------*/
}