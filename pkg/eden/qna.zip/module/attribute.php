<?php //-->
/*
 * This file is part of the Eve package.
 * (c) 2011-2012 Openovate Labs
 *
 * Copyright and license information can be found at LICENSE.txt
 * distributed with this package.
 */

/**
 * Attribute Module
 *
 * @package    Eve
 * @category   module
 * @author     Christian Blanquera cblanquera@openovate.com
 */
class Attribute extends Eden_Class {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	protected $_database 	= NULL;
	
	/* Private Properties
	-------------------------------*/
	/* Magic
	-------------------------------*/
	public static function i() {
		return self::_getSingleton(__CLASS__);
	}
	
	public function __construct(Eden $app = NULL, $key = NULL) {
		if(is_null($app)) {
			$app = Eden::i()->getActiveApp();
		}
		
		$this->_database 	= $app->database($key);
	}
	
	/* Public Methods
	-------------------------------*/
	/**
	 * installs the relation table
	 *
	 * @return this
	 */
	public function install() {
		$this->_database->query(self::$_schema);
		return $this;
	}
	
	/**
	 * Sets attribute data
	 *
	 * @param string
	 * @param string|int
	 * @param string
	 * @param scalar
	 * @return this
	 */
	public function set($table, $id, $name, $value) {
		Attribute_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int')
			->argument(3, 'string')
			->argument(4, 'scalar');
		
		//check to see if this attribute exists	
		$row = $this->Relation()
			->search($table, $id, 'attribute')
			->filterByAttributeName($name)
			->getRow();
		
		//if it's not set
		if(!$row) {
			//insert it
			$attribute = $this->_database->insertRow('attribute', array(
				'attribute_name' 	=> $name,
				'attribute_value' 	=> $value))
			->getLastInsertedId();
			
			//also add it to the relation
			$this->Relation()->add($table, $id, 'attribute', $attribute);
			
			return $this;
		}
		
		//at this point it exists
		//update it
		$this->_database->updateRows('attribute', 
			array('attribute_value' => $value), 
			'attribute_id='.$row['attribute_id']);
		
		return $this;
	}
	
	/**
	 * Removes attribute data
	 *
	 * @param string
	 * @param string|int
	 * @param string
	 * @return this
	 */
	public function remove($table, $id, $name) {
		Attribute_Error::i()
			->argument(1, 'string')
			->argument(2, 'string', 'int')
			->argument(3, 'string');
		
		//check to see if relation exists already
		$rows = $this->Relation()
			->search($table, $id, 'attribute', false, true)
			->filterByAttributeName($name)
			->getRows();
		
		//if relation doesn't exist
		if(!isset($rows[0])) {
			//do nothing
			return $this;
		}
		
		//at this point it means that the relation exists
		
		//remove it from the relation
		$this->Relation()->remove($table, $id, 'attribute', $rows[0]['attribute_id']);
		
		//remove it from the attributes
		$this->_database->deleteRows('attribute', 
			array('attribute_value' => $value), 
			'attribute_id='.$rows[0]['attribute_id']);
		
		return $this;
	}
	
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
	/* Long Data
	-------------------------------*/
	private static $_schema = 
		'CREATE TABLE IF NOT EXISTS `attribute` (
		  `attribute_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		  `attribute_name` varchar(255) NOT NULL,
		  `attribute_value` text NOT NULL,
		  PRIMARY KEY (`attribute_id`),
		  KEY `attribute_name` (`attribute_name`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;';
}

/**
 * Attribute Error
 */
class Attribute_Error extends Eden_Error {
	/* Constants
	-------------------------------*/
	/* Public Properties
	-------------------------------*/
	/* Protected Properties
	-------------------------------*/
	/* Private Properties
	-------------------------------*/
	/* Get
	-------------------------------*/
	public static function i($message = NULL, $code = 0) {
		$class = __CLASS__;
		return new $class($message, $code);
	}
	
	/* Magic
	-------------------------------*/
	/* Public Methods
	-------------------------------*/
	/* Protected Methods
	-------------------------------*/
	/* Private Methods
	-------------------------------*/
}